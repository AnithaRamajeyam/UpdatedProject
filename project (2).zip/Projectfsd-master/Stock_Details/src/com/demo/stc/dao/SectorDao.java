package com.demo.stc.dao;

public interface SectorDao {

}
