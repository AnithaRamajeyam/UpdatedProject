package com.demo.stc.dao;

import com.demo.stc.domain.User;

public interface UserDao {

	public int registerUser(User user);
}
