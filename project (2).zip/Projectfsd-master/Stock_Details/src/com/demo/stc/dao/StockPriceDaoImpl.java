package com.demo.stc.dao;

public class StockPriceDaoImpl implements StockPriceDao {

}
