package com.demo.stc.dao;

import java.util.List;

import com.demo.stc.domain.StockExchange;

public interface StockExchangeDao {
	
	public int insertStockExchangeDetails(StockExchange stock);

	public List<StockExchange> getAllStockExchangedetails();

}
