package com.demo.stc.main;

import java.sql.SQLException;
import java.util.List;

import com.demo.stc.controller.CompanyController;
import com.demo.stc.controller.CompanyControllerImpl;
import com.demo.stc.controller.IPODetailController;
import com.demo.stc.controller.IPODetailControllerImpl;
import com.demo.stc.controller.UserController;
import com.demo.stc.controller.UserControllerImpl;
import com.demo.stc.domain.Company;
import com.demo.stc.domain.IPODetail;
import com.demo.stc.domain.User;

public class StockDetails {

	public static void main(String[] args) throws Exception {
		CompanyController controller=new CompanyControllerImpl();
		Company company=new Company();
		company.setCompanyName("CTS");
		company.setTurnOver(2232.56);
		company.setCeo("Brian");
		company.setBoardOfDirectors("XXXX");
		company.setSectorId(1);
		company.setBriefWriteup("aaaaaaaa");
		company.setStockCode(236541);
		int result=controller.insertCompany(company);
		if(result>0)
		{
			System.out.println("inserted sucessfully");
		}
		else
		{
			System.out.println(" not inserted ");

		}
		List<Company> list = controller.getCompanyList();
		System.out.println(list);
	
		UserController usercontroller=new UserControllerImpl();
			User user=new User("Anushya","anu","User","anu@gmail.com", 9487154703L, false);;;
			int result1=usercontroller.registerUser(user);
			if(result1>0)
			{
				System.out.println("inserted sucessfully");
			}
			else
			{
				System.out.println(" not inserted ");

			}
		
		IPODetailController ipocontroller=new IPODetailControllerImpl();
		IPODetail ipodetail=new IPODetail(26,1000,200.36,5,"25/5/2019","definition");
		int result2=ipocontroller.insertIPODetail(ipodetail);
		if(result2>0)
		{
			System.out.println("inserted ipo sucessfully");
		}
		else
		{
			System.out.println(" not inserted ");

		}
	
	}

}
