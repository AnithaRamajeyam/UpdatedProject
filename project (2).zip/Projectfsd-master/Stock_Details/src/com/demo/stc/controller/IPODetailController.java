package com.demo.stc.controller;

import java.sql.SQLException;
import java.util.List;

import com.demo.stc.domain.IPODetail;

public interface IPODetailController {
	
	public int insertIPODetail(IPODetail ipodetail) throws SQLException;
	public List<IPODetail> getAllIPOPLanned() throws Exception;
}
