package com.demo.stc.controller;
import java.sql.SQLException;
import java.util.List;

import com.demo.stc.domain.Company;
import com.demo.stc.service.CompanyService;
import com.demo.stc.service.CompanyServiceImpl;

public class CompanyControllerImpl implements CompanyController{
	
	CompanyService service=new CompanyServiceImpl();
	
	@Override
	public int insertCompany(Company company) throws SQLException {
		int result=service.insertCompany(company);
		return result;	
	}

	@Override
	public boolean updateCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Company> getCompanyList() throws Exception {
		List<Company> list=service.getCompanyList();
		return list;
	}

}
