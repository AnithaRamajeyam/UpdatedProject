package com.demo.stc.controller;

import java.sql.SQLException;
import java.util.List;

import com.demo.stc.domain.IPODetail;
import com.demo.stc.service.IPODetailService;
import com.demo.stc.service.IPODetailServiceImpl;

public class IPODetailControllerImpl implements IPODetailController {

		IPODetailService service=new IPODetailServiceImpl();
	@Override
	public int insertIPODetail(IPODetail ipodetail) throws SQLException {
		int result=service.insertIPODetail(ipodetail);
		return result;
	}

	@Override
	public List<IPODetail> getAllIPOPLanned() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
