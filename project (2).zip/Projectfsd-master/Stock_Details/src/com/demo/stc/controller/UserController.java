package com.demo.stc.controller;

import com.demo.stc.domain.User;

public interface UserController {
	
	public int registerUser(User user);

}
