package com.demo.stc.service;

import java.sql.SQLException;
import java.util.List;
import com.demo.stc.domain.StockExchange;

public interface StockExchangeService {
	public int insertStockExchangeDetails(StockExchange stock) throws SQLException;
	public List<StockExchange> getAllStockExchangedetails() throws Exception;
}
