package com.demo.stc.service;

import java.sql.SQLException;
import java.util.List;

import com.demo.stc.dao.CompanyDao;
import com.demo.stc.dao.CompanyDaoImpl;
import com.demo.stc.domain.Company;

public class CompanyServiceImpl implements CompanyService {

	CompanyDao dao;
	@Override
	public int insertCompany(Company company) throws SQLException {
		dao=new CompanyDaoImpl();
		int result=dao.insertCompany(company);
		return result;
	}

	@Override
	public boolean updateCompany(Company company) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Company> getCompanyList() throws Exception {
		dao=new CompanyDaoImpl();
		List<Company> list=dao.getCompanyList();
		return list;
	}

}
